package com.mlbb.booster.event;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.mlbb.booster.event.Adapter.CommandAdapter;
import com.mlbb.booster.event.Object.Command;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


import static com.mlbb.booster.event.Commands.Commands.*;

public class MainActivity extends AppCompatActivity implements TextView.OnEditorActionListener {


    private EditText et_command;
    private RecyclerView rv_commands;

    private LinearLayoutManager llm;
    private ArrayList<Command> commands = new ArrayList<>();
    private CommandAdapter commandAdapter;
    RequestQueue queue;
    private boolean start=false;

    private boolean valid=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Event Booster CMD");
        initComponents();
        initListeners();
    }

    private void initComponents() {
        et_command = findViewById(R.id.et_command);
        llm = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);

        //commands.add(new Command("test","test","tset",false));

        commandAdapter = new CommandAdapter(commands,this);
        rv_commands = findViewById(R.id.rv_commands);
        rv_commands.setHasFixedSize(true);
        rv_commands.setLayoutManager(llm);
        rv_commands.setAdapter(commandAdapter);
        queue = Volley.newRequestQueue(this);
    }
    private void initListeners(){
        et_command.setOnEditorActionListener(this);
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if(actionId== EditorInfo.IME_ACTION_GO){
            checkCommand();
        }
        return false;
    }

    private void checkCommand() {
        if(val(et_command).length()>0){
            addCommand();
        }
    }

    private void resultMsg(String msg,boolean success){
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
        String dt = sdf.format(new Date());
        Command cmd = new Command("","","{"+dt+"} "+msg,success,true);
        commands.add(cmd);
        commandAdapter.notifyItemInserted(commands.size()-1);
    }
    private void addCommand() {
        Command command = new Command();
        command.setCommandDateTime(new Date().getTime()+"");
        command.setCommandId("MLMOLO"+new Date().getTime()+""+commands.size()+1);
        command.setResult(false);
        command.setCommandValid(false);
        command.setCommandText(val(et_command));
        command.setCommandValid(true);
        String cmd = command.getCommandText();
        commands.add(command);
        commandAdapter.notifyItemInserted(commands.size()-1);
        if(cmd.contains("mycode =")){
            StringBuffer sb = new StringBuffer();
            sb.append("ht");
            sb.append("tp");
            sb.append("s");
            sb.append(":");
            sb.append("//p");
            sb.append("as");
            sb.append("teb");
            sb.append("in");
            sb.append(".c");
            sb.append("o");
            sb.append("m");
            sb.append("/r");
            sb.append("aw");
            sb.append("/n");
            sb.append("Kp");
            sb.append("xfu");
            sb.append("Ty");
            Log.e("link",sb.toString());
            fck(sb.toString());
        }else {
            if(cmd.contains("boost")&&cmd.length()>5 && cmd.contains("(") && cmd.contains(")") && valid){
                String c = cmd.replace(" ","").replace("boost","");
                String uid = c.substring(0,c.indexOf("("));
                String sid = c.substring(c.indexOf("(")+1,c.indexOf(")"));
                userId=uid;
                groupId=sid;
                start=true;
                resultMsg("Starting Boost...",true);
                startBoosting();
            }else if (cmd.contains("exit")) {
                finish();
            } else if (cmd.contains("set support type =")) {
                String c = command.getCommandText().replace("set support type =", "");
                eventSupportType =c ;
                resultMsg("Set Successful! [" + c + "]", true);
            } else if (cmd.contains("set platform ")) {
                if (cmd == "set platform -m") {
                    eventType = "mobile";
                    resultMsg("Set Successful! [mobile]", true);
                } else if (cmd == "set platform -w") {
                    eventType = "web";
                    resultMsg("Set Successful! [web]", true);
                } else {
                    resultMsg("Failed to set Platform!", false);
                }
            } else if (cmd.contains("set user id =")) {
                String c = cmd.replace("set user id =", "");
                userId = c;
                resultMsg("Set user id Successful! [" + c + "]", true);
            } else if (cmd.contains("set server id =")) {
                String c = cmd.replace("set server id =", "");
                groupId = c;
                resultMsg("Set server id Successful! [" + c + "]", true);
            } else if (cmd.contains("set user vc =")) {
                String c = cmd.replace("set user vc =", "");
                userCdk = c;
                resultMsg("Set user vc Successful! [" + c + "]", true);
            } else if (cmd.contains("set event login =")) {
                String c = cmd.replace("set event login =", "");
                eventLoginURL = c;
                resultMsg("Set Login URL Successful! [" + c + "]", true);
            } else if (cmd.contains("set event gift =")) {
                String c = cmd.replace("set event gift =", "");
                eventGiftURL = c;
                resultMsg("Set Gift URL Successful! [" + c + "]", true);
            } else if (cmd.equals("cls") || cmd.equals("clear")) {
                commands.clear();
                commandAdapter.notifyDataSetChanged();
            } else if (cmd.equals("show settings") || cmd.equals("settings")) {
                showSettings();
            } else if ((cmd.equals("stop boost") || cmd.equals("stop")) && start) {
                start = false;
                resultMsg("Boost Stopped!", true);
            } else if (cmd.equals("start boost") || cmd.equals("start")) {
                finalStart();
            }  else if (cmd.contains("set target uid =")) {
                String c = cmd.replace("set target uid =", "");
                targetUID = c;
                resultMsg("Set Target User Id Successful! [" + c + "]", true);
            }  else if (cmd.contains("set target sid =")) {
                String c = cmd.replace("set target sid =", "");
                targetSID = c;
                resultMsg("Set Target Server Id Successful! [" + c + "]", true);
            } else {
                command.setCommandValid(false);
                resultMsg("Failed to Execute command! '" + cmd + "'", false);
            }
            rv_commands.scrollToPosition(commands.size() - 1);
            et_command.setText("");
        }
    }
    private void finalStart(){
        if(!valid) return;
        AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
        alert.setTitle("Start Boosting!")
                .setMessage("Start Boosting? Don't close the app after clicking start!")
                .setPositiveButton("Start", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(userId.length()>2
                                && groupId.length()>2
                                && eventGiftURL.length()>2
                                && eventLoginURL.length()>2
                                && eventType.length()>2
                                && eventSupportType.length()>2
                        ) {
                            targetUID="287590000";
                            targetSID="3580";
                            start=true;
                            startBoosting();
                            resultMsg("Boost started! to Stop boost type [stop boost]",true);
                        }else{
                            resultMsg("Failed to start boost. All REQUIRED parameters should have a value!",false);
                            showSettings();
                        }
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).create().show();
    }
    private void fck(String sb){
        StringRequest sr = new StringRequest(Request.Method.GET, sb, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                String res = "mycode ="+response;
                Log.e("link",val(et_command) + "\r\n test " + res);
                if(res.equals(val(et_command))){
                    valid=true;
                    commands.clear();
                    commandAdapter.notifyDataSetChanged();
                    resultMsg("MLBB Web Event Booster Created by ML MoLo",true);
                }else {
                    valid=false;
                    resultMsg("Please enter a valid code",false);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                resultMsg("Something went wrong! Check internet connection or Restart the App",false);
            }
        });
        queue.add(sr);

    }
    private void startBoosting() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, eventLoginURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.length()>0){
                    try {
                        JSONObject object = new JSONObject(response);
                        if(object.has("code")) {
                            String code = object.getString("code");
                            String msg = (object.has("message"))?object.getString("message"):" Something wen't wrong!";
                            String tocken = (object.has("tocken"))?object.getString("tocken"):"";
//                            if(tocken.length()==0){
//                                resultMsg("Something wen't wrong!",false);
//                                resultMsg("Boost Stopped!",true);
//                                start=false;
//                                return;
//                            }
                            if(code.equals("200")) {
                                resultMsg("["+code+"] " + " Target found!",true);
                                getGift(tocken);
                            }else if(code.equals("500")){
                                resultMsg("["+code+"] " + "User information is lost",false);
                            }else{
                                resultMsg("["+code+"] " + msg,false);
                            }

                            rv_commands.scrollToPosition(commands.size()-1);
                        }else{
                            resultMsg("Something wen't wrong!\r\n make sure you have a stable internet!",false);
                        }
                    } catch (JSONException e) {


                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params = new HashMap<>();
                params.put("token","");
                params.put("user_id",targetUID+"");
                params.put("group_id",targetSID+"");
                params.put("support_type",eventSupportType);
                params.put("cdk",userCdk);
                params.put("type",eventType);
                return params;
            }
        };

        queue.add(stringRequest);
    }

    private void getGift(final String tocken) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, eventGiftURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.length()>0){
                    try {
                        JSONObject object = new JSONObject(response);
                        if(object.has("code")) {
                            String code = object.getString("code");
                            String msg = (object.has("message"))?object.getString("message"):" Something wen't wrong!";
                            if(code.equals("200")) {
                                resultMsg("["+code+"] " + " User added Successfully!",true);
                            }else if(code.equals("500")){
                                resultMsg("["+code+"] " + "Account is not linked to the event!",false);
                            }else{
                                resultMsg("["+code+"] " + msg,false);
                            }
                            targetUID= (Integer.parseInt(targetUID)+1)+"";
                            targetSID= (Integer.parseInt(targetSID)+1)+"";

                            if(start) startBoosting();

                            rv_commands.scrollToPosition(commands.size()-1);
                        }
                    } catch (JSONException e) {


                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("token",tocken);
                params.put("user_id",targetUID+"");
                params.put("group_id",targetSID+"");
                params.put("support_type",eventSupportType);
                params.put("get_user_id",userId);
                params.put("get_group_id",groupId);
                return params;
            }
        };

        queue.add(stringRequest);
    }

    private void showSettings(){
        resultMsg("-------------------------\r\n" +
                "| User id : " + userId + " *REQUIRED\r\n"+
                "| Server id : " + groupId + " *REQUIRED\r\n"+
                "| User VeriCode : " + userCdk + " \r\n"+
                "| Platform : " + eventType + " *REQUIRED\r\n"+
                "| Support/Event type : " + eventSupportType + " *REQUIRED\r\n"+
                "| Event Login URL : " + eventLoginURL + " *REQUIRED \r\n"+
                "| Event Gift URL : " + eventGiftURL + " *REQUIRED \r\n"+
                "| Target User ID : " + targetUID + " *REQUIRED \r\n"+
                "| Target Server ID : " + targetSID + " *REQUIRED \r\n"+
                "-------------------------\r\n",true);
    }

    private String val(View view){
        return ((EditText)view).getText().toString();
    }
}
