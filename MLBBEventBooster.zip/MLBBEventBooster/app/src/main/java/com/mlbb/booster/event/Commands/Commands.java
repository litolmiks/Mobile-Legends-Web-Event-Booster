package com.mlbb.booster.event.Commands;

import java.util.HashMap;
import java.util.Map;

public class Commands {

    //REQUIRED SETTINGS
    public static String eventSupportType = "SpringSell";
    public static String eventType = "mobile";
    public static String userCdk = "";
    public static String userId = "";
    public static String groupId = "";

    public static String targetUID="287590000";
    public static String targetSID="3580";
    //static Account boosterAccount = new Account();
    //public static Account targetAccount = new Account("287590000","3580");


    //ADVANCE SETTINGS

    public static String eventLoginURL = "https://eventapi.mobilelegends.com/comm_activity_api/Login";
    public static String eventGiftURL = "https://eventapi.mobilelegends.com/comm_activity_api/giveGiftSecondOrderByUser";

    public static class Account {

        String uid;//User id
        String sid;//Server id

        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        public String getSid() {
            return sid;
        }

        public void setSid(String sid) {
            this.sid = sid;
        }

        public Account(String uid, String sid) {
            this.uid = uid;
            this.sid = sid;
        }

        public Account() {
        }
    }
}
