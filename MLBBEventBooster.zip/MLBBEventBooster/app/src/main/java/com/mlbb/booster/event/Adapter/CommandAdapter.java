package com.mlbb.booster.event.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mlbb.booster.event.Object.Command;
import com.mlbb.booster.event.R;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CommandAdapter extends RecyclerView.Adapter<CommandAdapter.ViewHolder> {
    ArrayList<Command>commands = new ArrayList<>();
    Context context;

    public CommandAdapter(ArrayList<Command> commands,Context context) {
        this.commands = commands;
        this.context=context;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.command_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Command command = commands.get(position);
        if(command!=null){
            String commandTxt = command.getCommandText();
            if(command.isResult()) {
                int color = R.color.boosterRed;
                if(command.isCommandValid()){
                    //Success
                    color = R.color.boosterTurq;
                }
                holder.tv_command_txt.setTextColor(context.getResources().getColor(color));
            }
            holder.tv_command_txt.setText(((!command.isResult())?"M:\\L\\MoLo> ":"")+commandTxt);

        }
    }



    @Override
    public int getItemCount() {
        return commands.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        TextView tv_command_txt;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_command_txt = itemView.findViewById(R.id.tv_command_result);
        }
    }
}