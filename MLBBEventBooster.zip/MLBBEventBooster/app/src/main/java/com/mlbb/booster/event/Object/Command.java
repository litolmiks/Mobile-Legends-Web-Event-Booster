package com.mlbb.booster.event.Object;

public class Command {
    private String commandId;
    private String commandDateTime;
    private String commandText;
    private boolean commandValid;
    private boolean result;

    public String getCommandId() {
        return commandId;
    }

    public void setCommandId(String commandId) {
        this.commandId = commandId;
    }

    public String getCommandDateTime() {
        return commandDateTime;
    }

    public void setCommandDateTime(String commandDateTime) {
        this.commandDateTime = commandDateTime;
    }

    public String getCommandText() {
        return commandText;
    }

    public void setCommandText(String commandText) {
        this.commandText = commandText;
    }

    public boolean isCommandValid() {
        return commandValid;
    }

    public void setCommandValid(boolean commandValid) {
        this.commandValid = commandValid;
    }

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public Command() {
    }

    public Command(String commandId, String commandDateTime, String commandText, boolean commandValid, boolean result) {
        this.commandId = commandId;
        this.commandDateTime = commandDateTime;
        this.commandText = commandText;
        this.commandValid = commandValid;
        this.result = result;
    }
}
